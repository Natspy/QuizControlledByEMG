# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# All rights reserved.

"""Module providing BrainAmplifierPeer."""
from obci.peers.drivers.amplifiers.amplifier_peer import AmplifierPeer, register_amplifier_peer
from ..amplifiers import BrainCppAmplifier

__all__ = ('BrainAmplifierPeer',)
try:
    # Try to import also 32 channel brainamp peer
    import brainamp32.brainamp32_peer
except ImportError:
    pass


@register_amplifier_peer
class BrainAmplifierPeer(AmplifierPeer):
    """
    Driver for BrainAmplifier. Provides 8 channels EEG channels and 3 acceleration channels.

    Uses python3-obci-cpp-amplifiers binary extension module.
    """

    AmplifierClass = BrainCppAmplifier

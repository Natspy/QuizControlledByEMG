# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# All rights reserved.

"""Module proving utility base class for writing singleton apps."""
import logging
import os
import sys
import tempfile

LOG = logging.getLogger('SingletonApplication')


class SingleInstanceException(BaseException):
    """Raised when trying to create two or more instances of singleton app."""

    pass


class SingleApplicationInstance(object):
    """
    If you want to prevent your script from running in parallel just instantiate :class:`SingleApplicationInstance`.

    If is there another instance already running it will throw a
    `SingleInstanceException`.

    Single instance works by creating a lock file with a filename based on
    the full path to the script file.
    """

    def __new__(cls, *args, **kwargs):
        if cls is SingleApplicationInstance:
            cls = SingleWindowsApplication if sys.platform == 'win32' else SingleUnixApplication
        return object.__new__(cls)

    def __init__(self, flavor_id, basename=None, autolock=True):
        """
        Init SingletonApp.

         Providing a flavor_id will augment the filename with the provided
        ``flavor_id``, allowing you to create multiple singleton instances
        from the same file. This is particularly useful if you want specific
        functions to have their own singleton instances.

        :param flavor_id: string .
        :param basename: string - prefix to flavor_id.
        """
        super(SingleApplicationInstance, self).__init__()
        self.lock_file = self._get_lock_file_path(flavor_id, basename)
        self._lock_is_acquired = False
        if autolock:
            self.acquire()

    @classmethod
    def _get_lock_file_path(cls, flavor_id, basename=None):
        if basename is None:
            basename = os.path.splitext(os.path.abspath(sys.argv[0]))[0]
        basename += '-{}.lock'.format(flavor_id)
        basename = basename.replace("/", "-").replace(":", "").replace("\\", "-")
        lock_file_path = os.path.normpath(os.path.join(tempfile.gettempdir(), basename))
        LOG.debug("%s lock file: %s", cls.__name__, lock_file_path)
        return lock_file_path

    def acquire(self):
        self._lock_is_acquired = True

    def release(self):
        self._lock_is_acquired = False

    def __del__(self):
        """Remove lock."""
        if self._lock_is_acquired:
            try:
                self.release()
            except Exception as e:
                if LOG:
                    LOG.warning(e)
                else:
                    print("Unloggable error: %s" % e)


class SingleWindowsApplication(SingleApplicationInstance):
    def acquire(self):
        try:
            # file already exists, we try to remove (in case previous
            # execution was interrupted)
            if os.path.exists(self.lock_file):
                os.unlink(self.lock_file)
            self.fd = os.open(
                self.lock_file, os.O_CREAT | os.O_EXCL | os.O_RDWR)
            LOG.debug('Lock file ({}) has been acquired'.format(self.lock_file))
        except OSError:
            type, e, tb = sys.exc_info()
            if e.errno == 13:
                LOG.error("Another instance is already running, quitting.")
                raise SingleInstanceException()
            print(e.errno)
            raise
        else:
            super(SingleWindowsApplication, self).acquire()

    def release(self):
        if hasattr(self, 'fd'):
            os.close(self.fd)
            LOG.debug('Lock file ({}) has been released'.format(self.lock_file))
            os.unlink(self.lock_file)
            LOG.debug('Lock file ({}) has been removed'.format(self.lock_file))
            super(SingleWindowsApplication, self).release()


class SingleUnixApplication(SingleApplicationInstance):
    def acquire(self):
        self.fp = open(self.lock_file, 'w')
        self.fp.flush()
        import fcntl
        try:
            fcntl.lockf(self.fp, fcntl.LOCK_EX | fcntl.LOCK_NB)
            LOG.debug('Lock file ({}) has been acquired'.format(self.lock_file))
        except OSError:
            LOG.warning("Another instance is already running, quitting.")
            raise SingleInstanceException()
        else:
            super(SingleUnixApplication, self).acquire()

    def release(self):
        import fcntl
        fcntl.lockf(self.fp, fcntl.LOCK_UN)
        LOG.debug('Lock file ({}) has been released'.format(self.lock_file))
        if os.path.isfile(self.lock_file):
            os.unlink(self.lock_file)
            LOG.debug('Lock file ({}) has been removed'.format(self.lock_file))
            super(SingleUnixApplication, self).release()


class SingleProcessApplication(SingleApplicationInstance):
    _lock_files_created_in_this_process = set()

    def __new__(cls, *args, **kwargs):
        if cls is SingleProcessApplication:
            cls = SingleWindowsProcessApplication if sys.platform == 'win32' else SingleUnixProcessApplication
        return super(SingleProcessApplication, cls).__new__(cls, *args, **kwargs)

    def acquire(self):
        lockfile_exists = self.lock_file in type(self)._lock_files_created_in_this_process
        if lockfile_exists:
            raise SingleInstanceException(
                'Application is already running for this process.')
        else:
            super(SingleProcessApplication, self).acquire()
            type(self)._lock_files_created_in_this_process.add(self.lock_file)
            LOG.debug('Lock file ({}) remembered for this process'.format(self.lock_file))

    def release(self):
        super(SingleProcessApplication, self).release()
        type(self)._lock_files_created_in_this_process.discard(self.lock_file)
        LOG.debug('Lock file ({}) forgotten for this process'.format(self.lock_file))
        assert self.lock_file not in type(self)._lock_files_created_in_this_process


class SingleWindowsProcessApplication(SingleProcessApplication, SingleWindowsApplication):
    pass


class SingleUnixProcessApplication(SingleProcessApplication, SingleUnixApplication):
    pass

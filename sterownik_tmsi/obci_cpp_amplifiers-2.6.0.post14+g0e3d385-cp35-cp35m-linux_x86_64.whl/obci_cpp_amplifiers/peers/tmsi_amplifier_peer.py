# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# All rights reserved.

"""Package providing TMSI amplifier driver."""
from obci.peers.drivers.amplifiers.amplifier_peer import AmplifierPeer, register_amplifier_peer
from ..amplifiers import TmsiCppAmplifier

__all__ = ('TmsiAmplifierPeer',)


@register_amplifier_peer
class TmsiAmplifierPeer(AmplifierPeer):
    """TMSI amplifier Peer - driver for TMSI Porti 7 EEG amplifiers."""

    AmplifierClass = TmsiCppAmplifier

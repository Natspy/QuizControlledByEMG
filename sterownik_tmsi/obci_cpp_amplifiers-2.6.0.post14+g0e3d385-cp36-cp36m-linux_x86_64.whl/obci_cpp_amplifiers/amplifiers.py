# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# All rights reserved
import functools
import glob
import logging
import subprocess
import sys
from typing import List, Sequence, Optional

import _obci_cpp_amplifiers as obci_cpp_amplifiers

from obci.core import ObciException
from obci.drivers.eeg.eeg_amplifier import AmplifierDescription, EEGAmplifier
from obci.signal_processing.signal.data_generic_write_proxy import Impedance, SamplePacket
from obci_utils import singleton_app
from .brain_amp_timestamp_correcter import BrainAmpTimestampCorrecter


class CantConnectToAmplifier(RuntimeError):
    pass


class ConnectionAlreadyMade(RuntimeError):
    pass


class _CppEEGAmplifier(EEGAmplifier):
    name = 'CppAmplifier'

    @classmethod
    def _get_cpp_amplifier_class(cls):
        raise NotImplementedError()

    @classmethod
    def get_available_amplifiers(cls, device_type: Optional[str] = None) -> List[str]:
        raise NotImplementedError()

    @classmethod
    def get_description(cls, id: Optional[str] = None) -> AmplifierDescription:
        try:
            amplifier = cls._get_cpp_amplifier(id)
        except RuntimeError as exc:
            raise ConnectionAlreadyMade(
                "Try accesing description from 'current_description' property "
                "on instance.".format(name=cls.name, id=id)
            ) from exc
        else:
            description = amplifier.get_description()
            del amplifier
            return AmplifierDescription.from_dict(description)

    @classmethod
    def _id_to_params(cls, id: Optional[str] = None) -> dict:
        raise NotImplementedError()

    def __init__(self, id: Optional[str] = None):
        try:
            self._cpp_amp = self._get_cpp_amplifier(id)
        except RuntimeError as exc:
            raise CantConnectToAmplifier from exc
        self._description = AmplifierDescription.from_dict(self._cpp_amp.get_description())
        super().__init__(id)

    @property
    def sampling_rate(self) -> int:
        return self._cpp_amp.get_sampling_rate()

    @sampling_rate.setter
    def sampling_rate(self, sampling_rate: int):
        self._cpp_amp.set_sampling_rate(sampling_rate)
        EEGAmplifier.sampling_rate.fset(self, sampling_rate)

    @property
    def active_channels(self) -> Sequence[str]:
        return self._cpp_amp.get_active_channels()

    @active_channels.setter
    def active_channels(self, active_channels):
        self._cpp_amp.set_active_channels(active_channels)
        EEGAmplifier.active_channels.fset(self, active_channels)

    def start_sampling(self):
        super().start_sampling()
        self._cpp_amp.start_sampling()

    def stop_sampling(self):
        self._cpp_amp.stop_sampling()
        super().stop_sampling()

    def _get_samples(self, samples_per_packet=1) -> SamplePacket:
        samples, timestamps, impedances = self._cpp_amp.get_samples_vec(samples_per_packet)
        impedance = Impedance(self._impedance_flags, impedances)
        return SamplePacket(samples=samples, ts=timestamps, impedance=impedance)

    def _wait(self, samples: Optional[int] = 1):
        pass

    @classmethod
    def _get_cpp_amplifier(cls, id: Optional[str] = None) -> obci_cpp_amplifiers.PyAmplifier:
        amplifier_class = cls._get_cpp_amplifier_class()
        params = cls._id_to_params(id)
        logger = logging.getLogger(cls.name)
        instance = amplifier_class(params, logger.info)
        return instance


class DummyCppAmplifier(_CppEEGAmplifier):
    name = 'DummyCppAmplifier'

    DUMMY_AMP_ID = 'CPP_DUMMY'

    @classmethod
    def get_available_amplifiers(cls, device_type: Optional[str] = None) -> List[str]:
        if device_type is None or device_type == 'virtual':
            return [cls.DUMMY_AMP_ID]  # some irrelevant name
        return []

    @classmethod
    def _get_cpp_amplifier_class(cls):
        return functools.partial(obci_cpp_amplifiers.PyAmplifier, 'DummyAmplifier')

    @classmethod
    def _id_to_params(cls, id: Optional[str] = None) -> dict:
        return {}


class BrainCppAmplifier(_CppEEGAmplifier):
    name = 'BrainCppAmplifier'
    MAX_BRAIN_AMPLIFIERS = 3

    def __init__(self, id: Optional[str] = None):
        self._hidden_pc_timestamp_added = False
        self._timestamp_correcter = None
        super().__init__(id)
        device_id = self._id_to_params(id)['device_index']
        self._lock = singleton_app.SingleProcessApplication(
            flavor_id=str(device_id), basename='obci.brainamp', autolock=False)

    def start_sampling(self):
        try:
            self._lock.acquire()
        except singleton_app.SingleInstanceException:
            raise CantConnectToAmplifier('Amplifier should already sampling')
        else:
            self._timestamp_correcter = BrainAmpTimestampCorrecter(sampling_rate=self.sampling_rate)
            self._cpp_amp.set_active_channels(tuple(list(self.active_channels) + ["PC Timestamp"]))
            self._hidden_pc_timestamp_added = True
            super().start_sampling()

    def stop_sampling(self):
        super().stop_sampling()
        self._cpp_amp.set_active_channels(self.active_channels)
        self._hidden_pc_timestamp_added = False
        self._lock.release()

    @classmethod
    def get_available_amplifiers(cls, device_type: Optional[str] = None) -> List[str]:
        if device_type is None or device_type == 'usb':
            locks = []
            try:
                for device_id in range(cls.MAX_BRAIN_AMPLIFIERS):
                    try:
                        lock = singleton_app.SingleProcessApplication(
                            flavor_id=str(device_id), basename='obci.brainamp')
                    except singleton_app.SingleInstanceException:
                        return []
                    else:
                        locks.append(lock)
                return obci_cpp_amplifiers.PyAmplifier.getAvailableBrainAmplifiers()
            finally:
                for lock in locks:
                    lock.release()
        return []

    @property
    def active_channels(self) -> Sequence[str]:
        """List of active channel names"""
        if self._hidden_pc_timestamp_added:
            return super().active_channels[:-1]
        else:
            return super().active_channels

    @active_channels.setter
    def active_channels(self, active_channels):
        _CppEEGAmplifier.active_channels.fset(self, active_channels)

    def get_samples(self, samples_per_packet=1):
        uncorrected_sample_packet = super().get_samples(samples_per_packet)
        if self._timestamp_correcter is not None:
            receive_timestamps = uncorrected_sample_packet.samples[:, -1]
            correct_timestamps = self._timestamp_correcter.get_corrected_timestamps(receive_timestamps,
                                                                                    uncorrected_sample_packet.ts)
            sample_packet = SamplePacket(samples=uncorrected_sample_packet.samples[:, :-1],
                                         ts=correct_timestamps,
                                         impedance=uncorrected_sample_packet.impedance)
            return sample_packet
        else:
            return uncorrected_sample_packet

    @classmethod
    def _get_cpp_amplifier_class(cls):
        return functools.partial(obci_cpp_amplifiers.PyAmplifier, 'BrainAmplifier')

    @classmethod
    def _id_to_params(cls, id: Optional[str] = None) -> dict:
        if id is None or id == '':
            return {'device_index': 0}
        else:
            device_index_str = id.rsplit(maxsplit=1)[-1]
            try:
                device_index = int(device_index_str)
            except ValueError:
                raise ObciException("Brain Amplifier is not found!")
            else:
                expected_cpp_amplifier_index = device_index - 1
                return {'device_index': expected_cpp_amplifier_index}


class TmsiCppAmplifier(_CppEEGAmplifier):
    name = 'TmsiCppAmplifier'

    USB_AMPLIFIER = obci_cpp_amplifiers.TMSI_USB_AMPLIFIER
    BLUETOOTH_AMPLIFIER = obci_cpp_amplifiers.TMSI_BLUETOOTH_AMPLIFIER
    IP_AMPLIFIER = obci_cpp_amplifiers.TMSI_IP_AMPLIFIER
    FILE_AMPLIFIER = obci_cpp_amplifiers.TMSI_FILE_AMPLIFIER

    DEVICE_TYPE_PREFIXES = (
        ('usb://', USB_AMPLIFIER),
        ('bt://', BLUETOOTH_AMPLIFIER),
        ('ip://', IP_AMPLIFIER),
        ('file://', FILE_AMPLIFIER)
    )

    @classmethod
    def get_available_amplifiers(cls, device_type: Optional[str] = None) -> List[str]:
        amplifiers = []
        if device_type is None or device_type == 'usb':
            amplifiers += ['usb://{}'.format(amp) for amp in cls._find_tmsi_usb_amps()]
        if device_type is None or device_type == 'bt':
            amplifiers += ['bt://{}'.format(amp) for amp in cls._find_tmsi_bluetooth_amps()]
        return amplifiers

    @classmethod
    def _get_cpp_amplifier_class(cls):
        return functools.partial(obci_cpp_amplifiers.PyAmplifier, 'TmsiAmplifier')

    @classmethod
    def _id_to_params(cls, id: Optional[str] = None) -> dict:
        if id is not None:
            for prefix, device_type in cls.DEVICE_TYPE_PREFIXES:
                if id.startswith(prefix):
                    if id == 'bt://':
                        btamp_ids = cls._find_tmsi_bluetooth_amps()
                        try:
                            id += btamp_ids[0]
                        except IndexError:
                            raise ObciException("No TMSi Bluetooth devices found.")
                    return {'device_type': device_type, 'device_url': id[len(prefix):]}
        tmsi_urls = cls._find_tmsi_usb_amps()
        return {'device_type': cls.USB_AMPLIFIER, 'device_url': tmsi_urls[0] if tmsi_urls else '/dev/tmsi0'}

    @staticmethod
    def _find_tmsi_usb_amps():
        if sys.platform.startswith('linux'):
            return list(glob.glob('/dev/tmsi*'))
        else:
            return []  # not implemented for other platforms

    @staticmethod
    def _find_tmsi_bluetooth_amps() -> List[str]:
        try:
            if sys.platform == 'linux':
                bl_s = subprocess.check_output(['hcitool', 'scan']).decode()
                nearby_devices = [line.strip().split('\t') for line in bl_s.splitlines()[1:]]
            else:
                nearby_devices = []
        except Exception as ex:
            logging.getLogger(__name__).warning("Bluetooth error: \n{}".format(ex))
            nearby_devices = []

        found = []
        for addr, name in nearby_devices:
            for amp_type in ['Porti7', 'MobiMini', 'Mobi5', 'Mobi6']:
                if name.startswith(amp_type):
                    parts = name.split()
                    try:
                        int(parts[1])
                    except ValueError:
                        pass
                    else:
                        found.append(addr)
        return found

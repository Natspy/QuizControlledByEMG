import os
import subprocess
import sys


def _apt_to_depends(requirements):
    reqs = []
    for req in requirements:
        if '=' in req:
            req = "{}(={})".format(*req.split('='))
        reqs.append(req)
    return reqs


def install_apt_requirements(apt_requirements, package_name):
    if '--print-apt-requirements' in sys.argv:
        print("\n".join(apt_requirements))
        sys.exit(0)
    if not apt_requirements:
        return
    elif 'GATHER_APT_REQUIREMENTS' in os.environ:
        with open(os.environ['GATHER_APT_REQUIREMENTS'], 'a') as f:
            f.write("\n".join(_apt_to_depends(apt_requirements)) + '\n')
    elif os.name == 'posix':
        cmd = "apt-get install -y " + " ".join(['"%s"' % req for req in apt_requirements])
        cmd = add_sudo_if_nonroot(cmd)
        print("Installing %s apt dependencies: \n %s" % (
            package_name, cmd))  # Sadly this is only visible when pip is run with '-v'
        if '--dry-run' in sys.argv:
            return
        os.system(cmd)


def add_sudo_if_nonroot(cmd):
    if os.geteuid() != 0:
        return "sudo " + cmd
    return cmd


def create_links(links, base_dir):
    if 'GATHER_LINKS' in os.environ:
        with open(os.environ['GATHER_LINKS'], 'a') as f:
            for src, dst in links:
                f.write("%s=%s\n" % (src, dst))
    else:
        if os.name == 'nt':
            return
        commands = [
            "ln -sfn %s %s" % (os.path.abspath(os.path.join(str(base_dir), str(src))), str(dst)) for src, dst in links
        ]
        udev = False
        for c in commands:
            c = add_sudo_if_nonroot(c)
            print(c)
            subprocess.check_call(c, shell=True)
            if 'udev' in c:
                udev = True
        if udev:
            c = add_sudo_if_nonroot("service udev restart")
            subprocess.check_call(c, shell=True)

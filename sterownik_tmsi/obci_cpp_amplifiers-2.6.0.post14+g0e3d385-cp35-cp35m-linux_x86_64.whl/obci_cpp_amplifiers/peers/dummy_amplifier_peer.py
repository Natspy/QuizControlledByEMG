# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# All rights reserved.

"""Module providing DummyAmplifierPeer."""
from obci.peers.drivers.amplifiers.amplifier_peer import AmplifierPeer, register_amplifier_peer
from ..amplifiers import DummyCppAmplifier

__all__ = ('DummyAmplifierPeer',)


@register_amplifier_peer
class DummyAmplifierPeer(AmplifierPeer):
    """
    Amplifier which sends different sinusoids, saws etc for testing.

    Uses python3-obci-cpp-amplifiers binary extension module.
    """

    AmplifierClass = DummyCppAmplifier

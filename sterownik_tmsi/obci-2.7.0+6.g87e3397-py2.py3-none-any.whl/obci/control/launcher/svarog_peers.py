# Copyright (c) 2016-2018 Braintech Sp. z o.o. [Ltd.] <http://www.braintech.pl>
# All rights reserved.

import enum
import pathlib
import uuid

import zmq

from obci.control.common import message as message_dispatching, net
from obci.control.launcher import launcher_tools
from obci.core import messages


class Status(enum.Enum):
    INITIALIZATION = 'initialization'
    SAVING = 'saving'
    FINISHING = 'finishing'
    FINISHED = 'finished'
    ERROR = 'error'


class Runner:
    class InvalidDataSent(Exception):
        def __init__(self, details: dict):
            self.details = details
            super().__init__()

    def __init__(self, experiments, machine, zmq_context):
        self._experiments = experiments
        self._machine = machine
        self._zmq_context = zmq_context
        self._saving_sessions = {}

    def handle_start_saving(self, message: messages.SvarogStartSavingSignal, sock):
        experiment_id = message.experiment_id
        saving_session_id = self._generate_new_session_id()
        try:
            self._validate_start_data(experiment_id)
        except self.InvalidDataSent as e:
            msg = messages.SvarogSavingSignalError(
                saving_session_id=saving_session_id,
                details=e.details,
            )
        else:
            session = self._create_session(experiment_id, saving_session_id)
            msg = messages.SvarogSavingSignalStarting(
                saving_session_id=saving_session_id,
            )
            session.start(message.signal_source_id, message.signal_filename,
                          message.save_tags, message.video_filename,
                          message.video_stream_url)
        msg.send(sock)

    def _generate_new_session_id(self):
        id = uuid.uuid4().hex[:4]
        is_already_taken = id in self._saving_sessions
        if is_already_taken:
            return self._generate_new_session_id()
        else:
            return id

    def _validate_start_data(self, experiment_id):
        is_experiment_present = experiment_id in self._experiments
        if not is_experiment_present:
            message = 'Experiment with id="{}" does not exist.'.format(experiment_id)
            raise self.InvalidDataSent(details={
                'message': message,
                'available experiments ids': list(self._experiments.keys()),
            })

    def _create_session(self, experiment_id, saving_session_id):
        experiment_info = self._experiments[experiment_id]
        session = SvarogSavingSession(id=saving_session_id,
                                      experiment_id=experiment_id,
                                      rep_addrs=experiment_info.rep_addrs,
                                      zmq_context=self._zmq_context,
                                      machine=self._machine)
        self._saving_sessions[saving_session_id] = session
        return session

    def handle_check_status(self, message: messages.SvarogCheckSavingSignalStatus,
                            sock):
        saving_session_id = message.saving_session_id
        try:
            session = self._saving_sessions[saving_session_id]
        except KeyError:
            messages.SvarogSavingSignalError(
                saving_session_id=saving_session_id,
                details={
                    'reason': 'passed session id is missing',
                    'present session ids': list(self._saving_sessions.keys()),
                },
            ).send(sock)
        else:
            messages.SvarogSavingSignalStatus(
                saving_session_id=saving_session_id,
                status=session.status.value,
            ).send(sock)

    def handle_finish_saving(self, message: messages.SvarogFinishSavingSignal, sock):
        saving_session_id = message.saving_session_id
        try:
            self._validate_finish_data(saving_session_id)
        except self.InvalidDataSent as e:
            msg = messages.SvarogSavingSignalError(
                saving_session_id=saving_session_id,
                details=e.details,
            )
        else:
            session = self._saving_sessions[saving_session_id]
            session.finish()
            msg = messages.SvarogSavingSignalFinishing(
                saving_session_id=saving_session_id,
            )
        msg.send(sock)

    def _validate_finish_data(self, saving_session_id):
        if saving_session_id not in self._saving_sessions:
            raise self.InvalidDataSent(details={
                'reason': 'passed session id is missing',
                'present session ids': list(self._saving_sessions.keys()),
            })
        session = self._saving_sessions[saving_session_id]
        experiment_id = session.experiment_id
        if experiment_id not in self._experiments:
            raise self.InvalidDataSent(details={
                'reason': 'experiment is gone',
                'experiment id': experiment_id,
            })
        status = session.status
        if status != Status.SAVING:
            raise self.InvalidDataSent(details={
                'reason': 'session is not saving',
                'current session status': str(status),
            })


class SvarogSavingSession:
    def __init__(self, id, experiment_id, rep_addrs, zmq_context, machine):
        self.id = id
        self.experiment_id = experiment_id
        self._rep_addrs = rep_addrs
        self._zmq_context = zmq_context
        self._machine = machine
        self._poller = message_dispatching.PollingObject()
        self._signal_saver_id = None
        self._video_saver_id = None
        self._finish_ran_manually = False

    def start(self, signal_source_id, signal_filename, save_tags,
              video_filename, video_stream_url):
        self._signal_saver_id = self._start_signal_saver(signal_source_id, signal_filename, save_tags)
        if video_stream_url:
            self._video_saver_id = self._start_video_saver(video_filename,
                                                           video_stream_url)

    def _start_signal_saver(self, signal_source_id, signal_filename, save_tags):
        peer_id = 'signal_saver_for_svarog-{}'.format(self.id)
        assert save_tags in ['0', '1']
        local_params = {
            'save_tags': save_tags,
            'send_panic_on_error': '0',
        }
        if signal_filename:
            path = pathlib.Path(signal_filename)
            file_name_passed = signal_filename[-1] != '/'
            if file_name_passed:
                local_params['save_file_name'] = path.name
                local_params['save_file_path'] = str(path.parent)
            else:
                local_params['save_file_path'] = str(path)
        message = messages.AddPeerMsg(
            peer_id=peer_id,
            peer_path='obci.peers.acquisition.signal_saver_peer',
            peer_type='obci_peer',
            machine=self._machine,
            param_overwrites=local_params,
            apply_globals=True,
            config_sources={'signal_source': signal_source_id},
            launch_dependencies={},
        )
        self._send_to_experiment(message)
        return peer_id

    def _start_video_saver(self, video_filename, video_stream_url):
        peer_id = 'video_saver_for_svarog-{}'.format(self.id)
        local_params = {
            'autostart': '1',
            'autoshutdown': '1',
            'stream_url': video_stream_url,
            'send_panic_on_error': '0',
        }
        if video_filename:
            if video_filename.endswith('/'):
                video_filename += 'video'
            saver_video_extension = '.mkv'
            if not video_filename.endswith(saver_video_extension):
                video_filename += saver_video_extension
            local_params['save_path'] = video_filename
        message = messages.AddPeerMsg(
            peer_id=peer_id,
            peer_path='obci_lab.peers.video.video_saver_peer',
            peer_type='obci_peer',
            machine=self._machine,
            param_overwrites=local_params,
            apply_globals=True,
            config_sources={},
            launch_dependencies={},
        )
        self._send_to_experiment(message)
        return peer_id

    @property
    def status(self):
        peers_to_check = []
        if self._signal_saver_id is not None:
            peers_to_check += [self._signal_saver_id]
        if self._video_saver_id is not None:
            peers_to_check += [self._video_saver_id]
        if not peers_to_check:
            if self._finish_ran_manually:
                return Status.FINISHED
            else:
                return Status.INITIALIZATION
        experiment_peers_statuses = self._get_peers_statuses()
        statuses = [experiment_peers_statuses.get(name, launcher_tools.FINISHED)
                    for name in peers_to_check]
        aggregated_status = self._aggregate_statuses(statuses)
        has_finished_prematurely = (aggregated_status == Status.FINISHED
                                    and not self._finish_ran_manually)
        if has_finished_prematurely:
            self.finish(is_manual=False)

            return Status.ERROR
        else:
            return aggregated_status

    def _get_peers_statuses(self):
        details = self._get_experiment_details()
        peers_statuses = details['experiment_status']['peers_status']
        return {peer_name: status_info['status_name']
                for peer_name, status_info in peers_statuses.items()}

    def _get_experiment_details(self):
        message = messages.GetExperimentInfoMsg()
        response = self._send_to_experiment(message)
        if response:
            response = messages.deserialize(response)
            assert isinstance(response, messages.ExperimentInfoMsg)
            return response.dict()
        else:
            assert False, "No response from the server."

    def _aggregate_statuses(self, statuses):
        failed_statuses = [
            launcher_tools.FAILED_LAUNCH,
            launcher_tools.FAILED,
        ]
        launching_statuses = [
            launcher_tools.NOT_READY,
            launcher_tools.READY_TO_LAUNCH,
            launcher_tools.LAUNCHING,
        ]
        running_statuses = [
            launcher_tools.RUNNING,
        ]
        finishing_statuses = [
            launcher_tools.STOPPING,
        ]
        finished_statuses = [
            launcher_tools.FINISHED,
            launcher_tools.TERMINATED,
        ]
        if any(s in failed_statuses for s in statuses):
            return Status.ERROR
        elif any(s in launching_statuses for s in statuses):
            return Status.INITIALIZATION
        elif any(s in finishing_statuses for s in statuses):
            return Status.FINISHING
        elif any(s in finished_statuses for s in statuses):
            return Status.FINISHED
        elif all(s in running_statuses for s in statuses):
            return Status.SAVING
        else:
            assert False, statuses

    def finish(self, is_manual=True):
        self._finish_ran_manually = self._finish_ran_manually or is_manual
        self._finish_peer(self._signal_saver_id)
        if self._video_saver_id:
            self._finish_peer(self._video_saver_id)

    def _finish_peer(self, peer_id):
        if peer_id is not None:
            message = messages.RemovePeerMsg(
                peer_id=peer_id,
                machine=self._machine,
            )
            self._send_to_experiment(message)

    def _send_to_experiment(self, message):
        rep_addrs = net.filter_not_local(self._rep_addrs) or self._rep_addrs
        sock = self._zmq_context.socket(zmq.REQ)
        try:
            for addr in rep_addrs:
                sock.connect(addr)
            message.send(sock)
            response, _ = self._poller.poll_recv(sock, 2000)
            return response
        finally:
            sock.close()
